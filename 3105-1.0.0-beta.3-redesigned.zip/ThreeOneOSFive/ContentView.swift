import SwiftUI

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @State private var selectedTab: Int

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab: Int
        if arguments.contains("--simulate-patch-tab") { initialTab = 2 }
        else if arguments.contains("--simulate-cleaner-tab") { initialTab = 3 }
        else if arguments.contains("--simulate-wallpaper-tab") { initialTab = 4 }
        else { initialTab = 0 }
        _selectedTab = State(initialValue: initialTab)
#else
        _selectedTab = State(initialValue: 0)
#endif
    }

    var body: some View {
        TabView(selection: $selectedTab) {
            DashboardView(selectedTab: $selectedTab).tabItem { Label(language.text("tab.home"), systemImage: "house.fill") }.tag(0)
            AppDataBrowserView().tabItem { Label(language.text("tab.files"), systemImage: "folder.fill") }.tag(1)
            PatchProjectsView().tabItem { Label(language.text("tab.patches"), systemImage: "shippingbox.fill") }.tag(2)
            CleanerView().tabItem { Label(language.text("tab.cleaner"), systemImage: "sparkles") }.tag(3)
            WallpaperLabView().tabItem { Label(language.text("tab.wallpapers"), systemImage: "photo.fill") }.tag(4)
        }
        .tint(AppTheme.accent)
        .preferredColorScheme(.dark)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { selectedTab = 2 }
        }
    }
}

private struct DashboardView: View {
    @Binding private var selectedTab: Int
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @State private var showLogs = false

    init(selectedTab: Binding<Int>) {
        _selectedTab = selectedTab
    }

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    header
                    deviceCard
                    quickActions
                    installationCard
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .padding(.bottom, 28)
            }
            .background(AppTheme.pageBackground.ignoresSafeArea())
            .navigationBarHidden(true)
            .sheet(isPresented: $showSettings) { SettingsView() }
            .sheet(isPresented: $showLogs) { LogView() }
        }
    }

    private var header: some View {
        HStack(spacing: 13) {
            AppLogo(size: 54)
                .shadow(color: AppTheme.accent.opacity(0.35), radius: 12)

            VStack(alignment: .leading, spacing: 3) {
                Text("3105")
                    .font(.title2.bold())
                Text("Device utility • iOS")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            HStack(spacing: 7) {
                Circle().fill(.green).frame(width: 8, height: 8)
                Text("READY")
                    .font(.caption2.weight(.bold).monospaced())
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 7)
            .background(.green.opacity(0.12), in: Capsule())
            .overlay(Capsule().stroke(.green.opacity(0.25), lineWidth: 1))
        }
    }

    private var deviceCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label("DEVICE STATUS", systemImage: "iphone")
                    .font(.caption.weight(.bold).monospaced())
                    .foregroundStyle(.secondary)
                Spacer()
                Image(systemName: appState.isSupported ? "checkmark.seal.fill" : "xmark.seal.fill")
                    .foregroundStyle(appState.isSupported ? .green : .red)
            }

            HStack(spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .fill(LinearGradient(colors: [AppTheme.accent.opacity(0.28), AppTheme.purple.opacity(0.22)], startPoint: .topLeading, endPoint: .bottomTrailing))
                    Image(systemName: "iphone.gen3")
                        .font(.system(size: 30, weight: .semibold))
                        .foregroundStyle(.white)
                }
                .frame(width: 62, height: 72)

                VStack(alignment: .leading, spacing: 5) {
                    Text(AppInfo.displayMachineName)
                        .font(.headline)
                    Text("iOS \(AppInfo.osVersion)")
                        .font(.subheadline.monospaced())
                        .foregroundStyle(.secondary)
                    Text(appState.isSupported ? "Compatible device" : "Compatibility check failed")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(appState.isSupported ? .green : .red)
                }
                Spacer()
            }
        }
        .padding(16)
        .background(AppTheme.cardBackground, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(AppTheme.cardStroke, lineWidth: 1))
        .shadow(color: .black.opacity(0.25), radius: 16, y: 8)
    }

    private var quickActions: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("QUICK ACTIONS")
                .font(.caption.weight(.bold).monospaced())
                .foregroundStyle(.secondary)

            HStack(spacing: 12) {
                DashboardAction(title: "Files", icon: "folder.fill", color: .blue) { selectedTab = 1 }
                DashboardAction(title: "Patches", icon: "shippingbox.fill", color: AppTheme.accent) { selectedTab = 2 }
                DashboardAction(title: "Cleaner", icon: "sparkles", color: .purple) { selectedTab = 3 }
                DashboardAction(title: "Wallpapers", icon: "photo.fill", color: .pink) { selectedTab = 4 }
            }
        }
    }

    private var installationCard: some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Installation")
                        .font(.headline)
                    Text(language.text("dashboard.enterprise_signing"))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "checkmark.shield.fill")
                    .font(.title2)
                    .foregroundStyle(AppTheme.accent)
            }

            HStack(spacing: 10) {
                DashboardButton(title: "Terminal", icon: "apple.terminal") { showLogs = true }
                DashboardButton(title: "Settings", icon: "gearshape.fill") { showSettings = true }
            }
        }
        .padding(16)
        .background(AppTheme.cardBackground, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(AppTheme.cardStroke, lineWidth: 1))
    }
}

private struct DashboardAction: View {
    let title: String
    let icon: String
    let color: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 9) {
                Image(systemName: icon)
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(color)
                    .frame(width: 38, height: 38)
                    .background(color.opacity(0.13), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                Text(title)
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(AppTheme.cardBackground, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(AppTheme.cardStroke, lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}

private struct DashboardButton: View {
    let title: String
    let icon: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .background(AppTheme.accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(AppTheme.accent.opacity(0.28), lineWidth: 1))
        }
        .buttonStyle(.plain)
        .foregroundStyle(.primary)
    }
}
