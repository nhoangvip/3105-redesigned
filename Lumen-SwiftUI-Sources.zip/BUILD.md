# Build & Export .ipa

## Cách 1 — Xcode GUI
1. Signing & Capabilities → chọn Team (Apple ID cá nhân cũng được).
2. Bundle Identifier duy nhất, ví dụ: com.yourname.lumen
3. Chọn thiết bị đích là "Any iOS Device (arm64)".
4. Product → Archive.
5. Organizer mở ra → Distribute App → chọn phương thức:
   - Custom → Debugging (ad-hoc/development) → Export → ra file .ipa
   - App Store Connect (nếu publish)

## Cách 2 — Dòng lệnh
```bash
xcodebuild -scheme Lumen \
  -configuration Release \
  -destination 'generic/platform=iOS' \
  -archivePath build/Lumen.xcarchive archive

xcodebuild -exportArchive \
  -archivePath build/Lumen.xcarchive \
  -exportOptionsPlist ExportOptions.plist \
  -exportPath build/ipa
```
File .ipa nằm tại build/ipa/Lumen.ipa
