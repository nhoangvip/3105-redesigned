//
//  CustomTabBar.swift
//  Thanh tab nổi (floating) với nền blur, pill chỉ báo trượt + haptic.
//

import SwiftUI

struct CustomTabBar: View {
    @Binding var selection: AppTab
    var namespace: Namespace.ID

    var body: some View {
        HStack(spacing: 6) {
            ForEach(AppTab.allCases) { tab in
                TabBarButton(
                    tab: tab,
                    isActive: selection == tab,
                    namespace: namespace
                ) {
                    guard selection != tab else {
                        Haptics.light()
                        return
                    }
                    Haptics.selection()
                    withAnimation(.spring(response: 0.42, dampingFraction: 0.78)) {
                        selection = tab
                    }
                }
            }
        }
        .padding(7)
        .background {
            Capsule(style: .continuous).fill(.ultraThinMaterial)
            Capsule(style: .continuous).fill(Color.white.opacity(0.05))
        }
        .overlay(Capsule(style: .continuous).strokeBorder(Palette.stroke, lineWidth: 1))
        .shadow(color: .black.opacity(0.6), radius: 26, x: 0, y: 14)
        .shadow(color: Color.neonViolet.opacity(0.22), radius: 30, x: 0, y: 10)
    }
}

private struct TabBarButton: View {
    let tab: AppTab
    let isActive: Bool
    var namespace: Namespace.ID
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 7) {
                Image(systemName: tab.icon)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(isActive ? Color.white : Color.white.opacity(0.45))
                    .scaleEffect(isActive ? 1.06 : 1)

                if isActive {
                    Text(tab.title)
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .fixedSize()
                        .transition(.opacity.combined(with: .scale(scale: 0.8, anchor: .leading)))
                }
            }
            .padding(.horizontal, isActive ? 16 : 14)
            .padding(.vertical, 11)
            .background {
                if isActive {
                    Capsule(style: .continuous)
                        .fill(Palette.hero)
                        .matchedGeometryEffect(id: "tabPill", in: namespace)
                        .shadow(color: Color.neonViolet.opacity(0.6), radius: 14, y: 6)
                }
            }
            .contentShape(Capsule())
        }
        .buttonStyle(.plain)
    }
}
