//
//  OtherViews.swift
//  Tab Thống kê · Thẻ · Cá nhân (toàn bộ dữ liệu là mock).
//

import SwiftUI

// MARK: - Insights

struct InsightsView: View {
    @EnvironmentObject private var app: AppState
    @State private var range: String = "Tuần"

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 22) {
                PageTitle(title: "Thống kê", subtitle: "Dòng tiền tháng 10/2026")
                    .padding(.horizontal, 20)

                FilterChips(items: ["Tuần", "Tháng", "Quý", "Năm"], selection: $range)
                    .padding(.horizontal, 20)

                VStack(alignment: .leading, spacing: 18) {
                    HStack(alignment: .firstTextBaseline) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Chi tiêu \(range.lowercased()) này")
                                .font(.system(size: 12.5, weight: .medium))
                                .foregroundStyle(.white.opacity(0.55))
                            Text(69_160_000.0.vnd)
                                .font(.system(size: 25, weight: .heavy, design: .rounded))
                                .foregroundStyle(.white)
                        }
                        Spacer()
                        Label("− 8,2%", systemImage: "arrow.down.right")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundStyle(Color.neonMint)
                            .padding(.horizontal, 10).padding(.vertical, 6)
                            .background(Capsule().fill(Color.neonMint.opacity(0.14)))
                    }

                    MiniBarChart(bars: Mock.weekly)
                }
                .glassCard(radius: 28, padding: 20)
                .padding(.horizontal, 20)

                VStack(spacing: 14) {
                    SectionHeader(title: "Theo danh mục", actionTitle: "Báo cáo") {
                        app.showToast("Tính năng đang phát triển", icon: "doc.richtext")
                    }

                    VStack(spacing: 12) {
                        ForEach(Mock.categories) { item in
                            CategoryRow(item: item)
                        }
                    }
                }
                .padding(.horizontal, 20)

                VStack(spacing: 14) {
                    SectionHeader(title: "Thông báo", actionTitle: "Lịch sử") {
                        app.showToast("Tính năng đang phát triển", icon: "bell")
                    }
                    ForEach(Mock.notifications) { note in
                        NotificationRow(note: note)
                    }
                }
                .padding(.horizontal, 20)

                Color.clear.frame(height: 110)
            }
            .padding(.top, 18)
        }
    }
}

struct CategoryRow: View {
    let item: CategorySpend

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: item.icon)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(item.tint)
                .frame(width: 42, height: 42)
                .background {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(item.tint.opacity(0.16))
                }

            VStack(alignment: .leading, spacing: 7) {
                HStack {
                    Text(item.name)
                        .font(.system(size: 14.5, weight: .semibold))
                        .foregroundStyle(.white)
                    Spacer()
                    Text(item.amount.vnd)
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.85))
                }
                ProgressBar(progress: Double(item.percent) / 100 * 2.2, tint: item.tint)
            }
        }
        .glassCard(radius: 22, padding: 14)
    }
}

struct NotificationRow: View {
    let note: AppNotification

    var body: some View {
        HStack(alignment: .top, spacing: 13) {
            Image(systemName: note.icon)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(note.tint)
                .frame(width: 38, height: 38)
                .background(Circle().fill(note.tint.opacity(0.16)))

            VStack(alignment: .leading, spacing: 4) {
                Text(note.title)
                    .font(.system(size: 14.5, weight: .semibold))
                    .foregroundStyle(.white)
                Text(note.detail)
                    .font(.system(size: 12.5))
                    .foregroundStyle(.white.opacity(0.55))
                    .fixedSize(horizontal: false, vertical: true)
                Text(note.time)
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(.white.opacity(0.35))
            }
            Spacer(minLength: 0)
        }
        .glassCard(radius: 22, padding: 14)
    }
}

// MARK: - Cards

struct CardsView: View {
    @EnvironmentObject private var app: AppState
    @State private var frozen: Bool = false
    @State private var limitIndex: Int = 2
    private let limits = [10, 20, 50, 100]

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 22) {
                PageTitle(title: "Thẻ của tôi", subtitle: "3 thẻ đang hoạt động")
                    .padding(.horizontal, 20)

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 16) {
                        ForEach(Mock.cards) { card in
                            CreditCardView(card: card)
                                .onTapGesture {
                                    Haptics.soft()
                                    app.showToast("Thẻ \(card.bank) ••\(card.last4)", icon: "creditcard")
                                }
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 4)
                }
                .scrollClipDisabled_iOS16()

                VStack(spacing: 14) {
                    SectionHeader(title: "Cài đặt thẻ", actionTitle: "Trợ giúp") {
                        app.showToast("Tính năng đang phát triển", icon: "questionmark.circle")
                    }

                    VStack(spacing: 12) {
                        ToggleRow(icon: "snowflake", tint: .neonCyan,
                                  title: "Đóng băng thẻ",
                                  subtitle: frozen ? "Thẻ đang tạm khoá" : "Thẻ đang hoạt động",
                                  isOn: $frozen)

                        StepperRow(icon: "gauge.with.dots.needle.33percent", tint: .neonAmber,
                                   title: "Hạn mức ngày",
                                   value: "\(limits[limitIndex]) triệu ₫",
                                   onMinus: { if limitIndex > 0 { Haptics.light(); limitIndex -= 1 } },
                                   onPlus:  { if limitIndex < limits.count - 1 { Haptics.light(); limitIndex += 1 } })

                        ActionRow(icon: "lock.rotation", tint: .neonViolet,
                                  title: "Đổi mã PIN", subtitle: "Cập nhật 2 tháng trước")
                        ActionRow(icon: "globe.asia.australia.fill", tint: .neonMint,
                                  title: "Thanh toán quốc tế", subtitle: "Đang bật cho 14 quốc gia")
                    }
                }
                .padding(.horizontal, 20)

                Color.clear.frame(height: 110)
            }
            .padding(.top, 18)
        }
    }
}

struct CreditCardView: View {
    let card: PaymentCard

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(card.bank)
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                    Text("Virtual · Visa")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.white.opacity(0.6))
                }
                Spacer()
                Image(systemName: card.scheme)
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.9))
            }

            Spacer()

            Text("•••• •••• •••• \(card.last4)")
                .font(.system(size: 18, weight: .semibold, design: .monospaced))
                .foregroundStyle(.white.opacity(0.95))
                .padding(.bottom, 14)

            HStack(alignment: .bottom) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("CHỦ THẺ")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundStyle(.white.opacity(0.55))
                    Text(card.holder)
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(.white)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    Text("SỐ DƯ")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundStyle(.white.opacity(0.55))
                    Text(card.balance.vnd)
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                }
            }
        }
        .padding(20)
        .frame(width: 290, height: 182)
        .background {
            RoundedRectangle(cornerRadius: 26, style: .continuous)
                .fill(LinearGradient(colors: card.colors, startPoint: .topLeading, endPoint: .bottomTrailing))
                .overlay {
                    RoundedRectangle(cornerRadius: 26, style: .continuous)
                        .fill(RadialGradient(colors: [.white.opacity(0.25), .clear],
                                             center: .topTrailing, startRadius: 4, endRadius: 220))
                }
        }
        .overlay {
            RoundedRectangle(cornerRadius: 26, style: .continuous)
                .strokeBorder(Color.white.opacity(0.2), lineWidth: 1)
        }
        .shadow(color: card.colors.first?.opacity(0.4) ?? .black, radius: 22, y: 14)
    }
}

// MARK: - Rows dùng chung

struct ToggleRow: View {
    let icon: String
    let tint: Color
    let title: String
    let subtitle: String
    @Binding var isOn: Bool

    var body: some View {
        HStack(spacing: 14) {
            IconBadge(icon: icon, tint: tint)
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.system(size: 14.5, weight: .semibold)).foregroundStyle(.white)
                Text(subtitle).font(.system(size: 12)).foregroundStyle(.white.opacity(0.5))
            }
            Spacer(minLength: 6)
            Toggle("", isOn: $isOn)
                .labelsHidden()
                .tint(tint)
                .onChange(of: isOn) { _ in Haptics.rigid() }
        }
        .glassCard(radius: 22, padding: 14)
    }
}

struct StepperRow: View {
    let icon: String
    let tint: Color
    let title: String
    let value: String
    let onMinus: () -> Void
    let onPlus: () -> Void

    var body: some View {
        HStack(spacing: 14) {
            IconBadge(icon: icon, tint: tint)
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.system(size: 14.5, weight: .semibold)).foregroundStyle(.white)
                Text(value)
                    .font(.system(size: 12.5, weight: .bold, design: .rounded))
                    .foregroundStyle(tint)
                    .contentTransition(.numericText())
            }
            Spacer(minLength: 6)
            HStack(spacing: 8) {
                CircleIconButton(icon: "minus", action: onMinus)
                CircleIconButton(icon: "plus",  action: onPlus)
            }
        }
        .glassCard(radius: 22, padding: 14)
    }
}

struct ActionRow: View {
    @EnvironmentObject private var app: AppState
    let icon: String
    let tint: Color
    let title: String
    let subtitle: String

    var body: some View {
        Button {
            Haptics.soft()
            app.showToast("Tính năng đang phát triển", icon: icon)
        } label: {
            HStack(spacing: 14) {
                IconBadge(icon: icon, tint: tint)
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(.system(size: 14.5, weight: .semibold)).foregroundStyle(.white)
                    Text(subtitle).font(.system(size: 12)).foregroundStyle(.white.opacity(0.5))
                }
                Spacer(minLength: 6)
                Image(systemName: "chevron.right")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(.white.opacity(0.35))
            }
            .glassCard(radius: 22, padding: 14)
        }
        .bouncy(0.97)
    }
}

struct IconBadge: View {
    let icon: String
    let tint: Color

    var body: some View {
        Image(systemName: icon)
            .font(.system(size: 16, weight: .semibold))
            .foregroundStyle(tint)
            .frame(width: 42, height: 42)
            .background {
                RoundedRectangle(cornerRadius: 14, style: .continuous).fill(tint.opacity(0.16))
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .strokeBorder(tint.opacity(0.3), lineWidth: 1)
            }
    }
}

struct CircleIconButton: View {
    let icon: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: 32, height: 32)
                .background {
                    Circle().fill(.ultraThinMaterial)
                    Circle().strokeBorder(Color.white.opacity(0.18), lineWidth: 1)
                }
        }
        .bouncy(0.86)
    }
}

struct PageTitle: View {
    let title: String
    let subtitle: String

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.system(size: 28, weight: .heavy, design: .rounded))
                .foregroundStyle(.white)
            Text(subtitle)
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(.white.opacity(0.5))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

// MARK: - Profile

struct ProfileView: View {
    @EnvironmentObject private var app: AppState
    @State private var faceID = true
    @State private var notify = true
    @State private var points = 1_240

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 22) {
                VStack(spacing: 14) {
                    ZStack {
                        Circle().fill(Palette.hero).frame(width: 92, height: 92)
                        Text("MA")
                            .font(.system(size: 30, weight: .heavy, design: .rounded))
                            .foregroundStyle(.white)
                        Circle().strokeBorder(Color.white.opacity(0.25), lineWidth: 1.5)
                            .frame(width: 92, height: 92)
                    }
                    .shadow(color: Color.neonViolet.opacity(0.55), radius: 24, y: 12)

                    VStack(spacing: 4) {
                        Text("Nguyễn Minh Anh")
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                        Label("Thành viên Platinum", systemImage: "crown.fill")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(Color.neonAmber)
                            .padding(.horizontal, 12).padding(.vertical, 6)
                            .background(Capsule().fill(Color.neonAmber.opacity(0.14)))
                    }
                }
                .padding(.top, 16)

                HStack(spacing: 12) {
                    StatTile(value: "\(points)", label: "Điểm thưởng", icon: "star.fill", tint: .neonAmber)
                    StatTile(value: "28", label: "Giao dịch", icon: "arrow.left.arrow.right", tint: .neonCyan)
                    StatTile(value: "3", label: "Thẻ", icon: "creditcard.fill", tint: .neonViolet)
                }
                .padding(.horizontal, 20)

                Button {
                    Haptics.success()
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.7)) { points += 50 }
                    app.showToast("+50 điểm thưởng (demo)", icon: "star.circle.fill")
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "gift.fill")
                        Text("Nhận thưởng hằng ngày")
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                    }
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background {
                        RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Palette.hero)
                    }
                    .shadow(color: Color.neonIndigo.opacity(0.5), radius: 18, y: 10)
                }
                .bouncy(0.96)
                .padding(.horizontal, 20)

                VStack(spacing: 12) {
                    ToggleRow(icon: "faceid", tint: .neonCyan, title: "Đăng nhập Face ID",
                              subtitle: faceID ? "Đang bật" : "Đang tắt", isOn: $faceID)
                    ToggleRow(icon: "bell.badge.fill", tint: .neonPink, title: "Thông báo đẩy",
                              subtitle: notify ? "Nhận mọi cập nhật" : "Đã tắt", isOn: $notify)
                    ActionRow(icon: "shield.checkered", tint: .neonMint, title: "Bảo mật & Quyền riêng tư", subtitle: "2FA đang bật")
                    ActionRow(icon: "questionmark.bubble.fill", tint: .neonViolet, title: "Trung tâm hỗ trợ", subtitle: "Phản hồi trong 5 phút")
                    ActionRow(icon: "rectangle.portrait.and.arrow.right", tint: .neonAmber, title: "Đăng xuất", subtitle: "Tài khoản minhanh@lumen.vn")
                }
                .padding(.horizontal, 20)

                Text("Lumen v1.0.0 (build 100) · SwiftUI · iOS 16+")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(.white.opacity(0.3))

                Color.clear.frame(height: 110)
            }
        }
    }
}

struct StatTile: View {
    let value: String
    let label: String
    let icon: String
    let tint: Color

    var body: some View {
        VStack(spacing: 7) {
            Image(systemName: icon)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(tint)
            Text(value)
                .font(.system(size: 18, weight: .heavy, design: .rounded))
                .foregroundStyle(.white)
                .contentTransition(.numericText())
            Text(label)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(.white.opacity(0.5))
        }
        .frame(maxWidth: .infinity)
        .glassCard(radius: 22, padding: 14)
    }
}
