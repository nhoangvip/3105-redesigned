//
//  LumenApp.swift
//  Lumen — Modern Dark Finance Dashboard
//
//  Target: iOS 16.0+ · Swift 5.9 / 6.x · SwiftUI
//  Không dùng bất kỳ thư viện bên thứ ba nào (no CocoaPods / no SPM).
//

import SwiftUI

@main
struct LumenApp: App {

    init() {
        // Ép dark mode ở mức UIKit để status bar / sheet luôn tối
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .forEach { $0.overrideUserInterfaceStyle = .dark }
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .preferredColorScheme(.dark)
                .environmentObject(AppState())
        }
    }
}

// MARK: - App State (mock / "logic rỗng")

final class AppState: ObservableObject {
    @Published var tab: AppTab = .home
    @Published var balanceHidden: Bool = false
    @Published var unreadCount: Int = 3
    @Published var toast: ToastMessage? = nil

    /// Hiển thị toast ngắn rồi tự ẩn sau 2.2s
    func showToast(_ text: String, icon: String = "sparkles") {
        Haptics.soft()
        withAnimation(.spring(response: 0.42, dampingFraction: 0.78)) {
            toast = ToastMessage(text: text, icon: icon)
        }
        let current = toast?.id
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.2) { [weak self] in
            guard let self, self.toast?.id == current else { return }
            withAnimation(.easeInOut(duration: 0.25)) { self.toast = nil }
        }
    }
}

struct ToastMessage: Identifiable, Equatable {
    let id = UUID()
    let text: String
    let icon: String
}

// MARK: - Tabs

enum AppTab: String, CaseIterable, Identifiable {
    case home, insights, cards, profile

    var id: String { rawValue }

    var title: String {
        switch self {
        case .home:     return "Tổng quan"
        case .insights: return "Thống kê"
        case .cards:    return "Thẻ"
        case .profile:  return "Cá nhân"
        }
    }

    var icon: String {
        switch self {
        case .home:     return "house.fill"
        case .insights: return "chart.bar.xaxis"
        case .cards:    return "creditcard.fill"
        case .profile:  return "person.fill"
        }
    }
}

// MARK: - Root

struct RootView: View {
    @EnvironmentObject private var app: AppState
    @Namespace private var tabNamespace

    var body: some View {
        ZStack(alignment: .bottom) {
            AuroraBackground()

            Group {
                switch app.tab {
                case .home:     HomeView()
                case .insights: InsightsView()
                case .cards:    CardsView()
                case .profile:  ProfileView()
                }
            }
            .transition(.opacity.combined(with: .offset(y: 12)))
            .animation(.easeInOut(duration: 0.28), value: app.tab)

            CustomTabBar(selection: $app.tab, namespace: tabNamespace)
                .padding(.horizontal, 22)
                .padding(.bottom, 10)
        }
        .ignoresSafeArea(.keyboard)
        .overlay(alignment: .top) {
            if let toast = app.toast {
                ToastView(message: toast)
                    .padding(.top, 8)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .zIndex(99)
            }
        }
    }
}

#Preview {
    RootView()
        .environmentObject(AppState())
        .preferredColorScheme(.dark)
}
