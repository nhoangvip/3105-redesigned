//
//  Theme.swift
//  Màu sắc, nền aurora, glassmorphism, haptics và button style.
//

import SwiftUI
import UIKit

// MARK: - Palette

extension Color {
    init(hex: UInt32, alpha: Double = 1) {
        self.init(
            .sRGB,
            red:   Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >>  8) & 0xFF) / 255,
            blue:  Double( hex        & 0xFF) / 255,
            opacity: alpha
        )
    }

    static let ink        = Color(hex: 0x07070C)   // nền đen sâu
    static let inkSoft    = Color(hex: 0x111119)
    static let neonViolet = Color(hex: 0x8B5CF6)
    static let neonIndigo = Color(hex: 0x5B5BFF)
    static let neonCyan   = Color(hex: 0x22D3EE)
    static let neonMint   = Color(hex: 0x34F5C5)
    static let neonPink   = Color(hex: 0xFF4D9D)
    static let neonAmber  = Color(hex: 0xFFB020)
}

enum Palette {
    static let hero = LinearGradient(
        colors: [Color.neonViolet, Color.neonIndigo, Color.neonCyan],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )

    static let mint = LinearGradient(
        colors: [Color.neonMint, Color.neonCyan],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )

    static let stroke = LinearGradient(
        colors: [Color.white.opacity(0.28), Color.white.opacity(0.04)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
}

// MARK: - Aurora background (các khối blur nhiều màu trên nền đen)

struct AuroraBackground: View {
    @State private var animate = false

    var body: some View {
        ZStack {
            Color.ink.ignoresSafeArea()

            Circle()
                .fill(Color.neonViolet.opacity(0.42))
                .frame(width: 360, height: 360)
                .blur(radius: 110)
                .offset(x: animate ? -120 : -90, y: animate ? -280 : -240)

            Circle()
                .fill(Color.neonCyan.opacity(0.30))
                .frame(width: 320, height: 320)
                .blur(radius: 120)
                .offset(x: animate ? 150 : 120, y: animate ? -120 : -170)

            Circle()
                .fill(Color.neonPink.opacity(0.22))
                .frame(width: 300, height: 300)
                .blur(radius: 130)
                .offset(x: animate ? -100 : -60, y: animate ? 320 : 280)
        }
        .ignoresSafeArea()
        .onAppear {
            withAnimation(.easeInOut(duration: 9).repeatForever(autoreverses: true)) {
                animate = true
            }
        }
    }
}

// MARK: - Glassmorphism

struct GlassCardModifier: ViewModifier {
    var radius: CGFloat = 26
    var padding: CGFloat = 18
    var strokeOpacity: Double = 1

    func body(content: Content) -> some View {
        content
            .padding(padding)
            .background {
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .fill(.ultraThinMaterial)
                    .overlay {
                        RoundedRectangle(cornerRadius: radius, style: .continuous)
                            .fill(Color.white.opacity(0.04))
                    }
            }
            .overlay {
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .strokeBorder(Palette.stroke.opacity(strokeOpacity), lineWidth: 1)
            }
            .shadow(color: .black.opacity(0.55), radius: 22, x: 0, y: 14)
    }
}

extension View {
    func glassCard(radius: CGFloat = 26, padding: CGFloat = 18) -> some View {
        modifier(GlassCardModifier(radius: radius, padding: padding))
    }

    /// Hiệu ứng nảy nhẹ khi chạm (micro-interaction)
    func bouncy(_ scale: CGFloat = 0.94) -> some View {
        buttonStyle(BouncyButtonStyle(scale: scale))
    }
}

struct BouncyButtonStyle: ButtonStyle {
    var scale: CGFloat = 0.94

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? scale : 1)
            .opacity(configuration.isPressed ? 0.88 : 1)
            .animation(.spring(response: 0.28, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

// MARK: - Haptics

enum Haptics {
    static func soft() {
        let generator = UIImpactFeedbackGenerator(style: .soft)
        generator.prepare()
        generator.impactOccurred(intensity: 0.7)
    }

    static func light() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    static func rigid() {
        UIImpactFeedbackGenerator(style: .rigid).impactOccurred(intensity: 0.9)
    }

    static func success() {
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }

    static func selection() {
        let generator = UISelectionFeedbackGenerator()
        generator.prepare()
        generator.selectionChanged()
    }
}

// MARK: - Helpers

extension Double {
    /// 12450.5 -> "12.450.500 ₫" (định dạng VN, mock)
    var vnd: String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.groupingSeparator = "."
        formatter.maximumFractionDigits = 0
        let value = formatter.string(from: NSNumber(value: self)) ?? "0"
        return value + " ₫"
    }
}
