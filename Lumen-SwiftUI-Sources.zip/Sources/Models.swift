//
//  Models.swift
//  Struct model + Mock Data phong phú (không API, không database).
//

import SwiftUI

// MARK: - Quick action

struct QuickAction: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let icon: String
    let tint: Color
}

// MARK: - Transaction

enum TxKind: String {
    case income  = "Nhận"
    case expense = "Chi"
}

struct Transaction: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let subtitle: String
    let icon: String
    let tint: Color
    let amount: Double
    let kind: TxKind
    let time: String

    var signedText: String {
        (kind == .income ? "+" : "−") + " " + amount.vnd
    }
}

// MARK: - Card

struct PaymentCard: Identifiable, Hashable {
    let id = UUID()
    let bank: String
    let holder: String
    let last4: String
    let balance: Double
    let scheme: String          // SF Symbol gợi ý
    let colors: [Color]
}

// MARK: - Insight / chart bar

struct InsightBar: Identifiable, Hashable {
    let id = UUID()
    let label: String
    let value: Double           // 0...1
}

struct CategorySpend: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let icon: String
    let tint: Color
    let percent: Int
    let amount: Double
}

// MARK: - Notification

struct AppNotification: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let detail: String
    let icon: String
    let tint: Color
    let time: String
}

// MARK: - Mock data

enum Mock {

    static let quickActions: [QuickAction] = [
        .init(title: "Chuyển tiền", icon: "arrow.left.arrow.right",      tint: .neonViolet),
        .init(title: "Nạp ví",      icon: "plus.circle.fill",            tint: .neonCyan),
        .init(title: "Quét QR",     icon: "qrcode.viewfinder",           tint: .neonMint),
        .init(title: "Hoá đơn",     icon: "doc.text.fill",               tint: .neonAmber),
        .init(title: "Tiết kiệm",   icon: "banknote.fill",               tint: .neonPink)
    ]

    static let transactions: [Transaction] = [
        .init(title: "Apple Store",     subtitle: "Mua sắm · Thẻ ••4921",  icon: "applelogo",             tint: .neonViolet, amount: 24_990_000, kind: .expense, time: "09:24"),
        .init(title: "Lương tháng 10",  subtitle: "Thu nhập · Vietcombank", icon: "arrow.down.left.circle.fill", tint: .neonMint,  amount: 38_500_000, kind: .income,  time: "08:02"),
        .init(title: "Spotify Premium", subtitle: "Giải trí · Định kỳ",     icon: "music.note",            tint: .neonPink,   amount: 59_000,     kind: .expense, time: "Hôm qua"),
        .init(title: "Grab Food",       subtitle: "Ăn uống · Ví Lumen",     icon: "fork.knife",            tint: .neonAmber,  amount: 185_000,    kind: .expense, time: "Hôm qua"),
        .init(title: "Hoàn tiền Shopee",subtitle: "Cashback · 5%",          icon: "arrow.uturn.left.circle.fill", tint: .neonCyan, amount: 142_000, kind: .income,  time: "T2"),
        .init(title: "Tiền điện EVN",   subtitle: "Hoá đơn · Tự động",      icon: "bolt.fill",             tint: .neonIndigo, amount: 820_000,    kind: .expense, time: "T2"),
        .init(title: "Gửi tiết kiệm",   subtitle: "Mục tiêu MacBook",       icon: "target",                tint: .neonMint,   amount: 5_000_000,  kind: .expense, time: "CN"),
        .init(title: "Uniqlo Vincom",   subtitle: "Thời trang · Thẻ ••1182",icon: "tshirt.fill",           tint: .neonViolet, amount: 1_290_000,  kind: .expense, time: "CN")
    ]

    static let cards: [PaymentCard] = [
        .init(bank: "Lumen Platinum", holder: "NGUYEN MINH ANH", last4: "4921", balance: 128_450_000,
              scheme: "wave.3.right", colors: [.neonViolet, .neonIndigo]),
        .init(bank: "Lumen Travel",   holder: "NGUYEN MINH ANH", last4: "1182", balance: 24_980_000,
              scheme: "airplane", colors: [.neonCyan, .neonMint]),
        .init(bank: "Lumen Black",    holder: "NGUYEN MINH ANH", last4: "7730", balance: 9_120_000,
              scheme: "moon.stars.fill", colors: [Color(hex: 0x3A3A46), Color(hex: 0x14141B)])
    ]

    static let weekly: [InsightBar] = [
        .init(label: "T2", value: 0.42), .init(label: "T3", value: 0.68),
        .init(label: "T4", value: 0.33), .init(label: "T5", value: 0.88),
        .init(label: "T6", value: 0.57), .init(label: "T7", value: 0.76),
        .init(label: "CN", value: 0.49)
    ]

    static let categories: [CategorySpend] = [
        .init(name: "Mua sắm",  icon: "bag.fill",            tint: .neonViolet, percent: 38, amount: 26_280_000),
        .init(name: "Ăn uống",  icon: "cup.and.saucer.fill", tint: .neonAmber,  percent: 24, amount: 16_600_000),
        .init(name: "Di chuyển",icon: "car.fill",            tint: .neonCyan,   percent: 18, amount: 12_450_000),
        .init(name: "Hoá đơn",  icon: "house.fill",          tint: .neonPink,   percent: 12, amount: 8_300_000),
        .init(name: "Khác",     icon: "ellipsis.circle.fill",tint: .neonMint,   percent:  8, amount: 5_530_000)
    ]

    static let notifications: [AppNotification] = [
        .init(title: "Giao dịch thành công", detail: "Bạn vừa thanh toán 185.000 ₫ tại Grab Food.", icon: "checkmark.seal.fill", tint: .neonMint, time: "2 phút trước"),
        .init(title: "Ưu đãi mới",           detail: "Hoàn 10% khi nạp ví trước 23:59 hôm nay.",    icon: "gift.fill",           tint: .neonPink, time: "1 giờ trước"),
        .init(title: "Cảnh báo ngân sách",   detail: "Danh mục Mua sắm đã dùng 86% hạn mức.",       icon: "exclamationmark.triangle.fill", tint: .neonAmber, time: "Hôm qua")
    ]

    static let goals: [(String, String, Double, Color)] = [
        ("MacBook Pro M4", "laptopcomputer", 0.72, .neonViolet),
        ("Du lịch Nhật Bản", "airplane.departure", 0.45, .neonCyan),
        ("Quỹ dự phòng", "shield.lefthalf.filled", 0.93, .neonMint)
    ]

    static var greeting: String {
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 5..<11:  return "Chào buổi sáng"
        case 11..<14: return "Chào buổi trưa"
        case 14..<18: return "Chào buổi chiều"
        default:      return "Chào buổi tối"
        }
    }
}
