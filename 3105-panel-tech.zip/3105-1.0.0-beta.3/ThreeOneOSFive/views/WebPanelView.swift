import SwiftUI
import WebKit

/// Các màn hình native của 3105 mà web có thể mở qua cầu nối.
enum NativeRoute: String, Identifiable, CaseIterable {
    case files, patches, cleaner, wallpapers, settings, logs
    var id: String { rawValue }
}

/// WKWebView chạy giao diện Panel Tech đóng gói trong app (web/index.html).
/// Web gọi native bằng:
///   window.webkit.messageHandlers.native.postMessage({ action: "open", target: "files" })
/// hoặc ngắn gọn: window.openNative("files")
struct WebPanelView: UIViewRepresentable {
    let onOpen: (NativeRoute) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(onOpen: onOpen) }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        let shim = """
        window.isNativeApp = true;
        window.openNative = function (target) {
          window.webkit.messageHandlers.native.postMessage({ action: 'open', target: target });
        };
        """
        config.userContentController.addUserScript(
            WKUserScript(source: shim, injectionTime: .atDocumentStart, forMainFrameOnly: true)
        )
        config.userContentController.add(context.coordinator, name: "native")

        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = context.coordinator
        web.isOpaque = false
        web.backgroundColor = UIColor(red: 10 / 255, green: 10 / 255, blue: 12 / 255, alpha: 1)
        web.scrollView.backgroundColor = web.backgroundColor
        web.scrollView.bounces = false
        web.scrollView.contentInsetAdjustmentBehavior = .never

        if let url = Bundle.main.url(forResource: "index", withExtension: "html") {
            web.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    static func dismantleUIView(_ uiView: WKWebView, coordinator: Coordinator) {
        uiView.configuration.userContentController.removeScriptMessageHandler(forName: "native")
    }

    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate {
        let onOpen: (NativeRoute) -> Void
        init(onOpen: @escaping (NativeRoute) -> Void) { self.onOpen = onOpen }

        func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.name == "native",
                  let body = message.body as? [String: Any],
                  body["action"] as? String == "open",
                  let target = body["target"] as? String,
                  let route = NativeRoute(rawValue: target) else { return }
            DispatchQueue.main.async { self.onOpen(route) }
        }

        // Link ngoài (http/https) mở bằng Safari, trang local và CDN script vẫn chạy trong WebView.
        func webView(_ webView: WKWebView,
                     decidePolicyFor action: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if action.navigationType == .linkActivated, let url = action.request.url,
               url.scheme == "http" || url.scheme == "https" {
                UIApplication.shared.open(url)
                decisionHandler(.cancel)
            } else {
                decisionHandler(.allow)
            }
        }
    }
}
