//
//  Components.swift
//  Header, Hero Card, Quick Actions, Transaction Row, Toast, Section Header…
//

import SwiftUI

// MARK: - Header

struct HeaderBar: View {
    @EnvironmentObject private var app: AppState
    var name: String = "Minh Anh"

    var body: some View {
        HStack(spacing: 14) {
            Button {
                Haptics.light()
                app.showToast("Tính năng đang phát triển", icon: "person.crop.circle")
            } label: {
                ZStack {
                    Circle()
                        .fill(Palette.hero)
                        .frame(width: 46, height: 46)
                    Text("MA")
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                    Circle()
                        .strokeBorder(Color.white.opacity(0.25), lineWidth: 1)
                        .frame(width: 46, height: 46)
                }
                .overlay(alignment: .bottomTrailing) {
                    Circle()
                        .fill(Color.neonMint)
                        .frame(width: 12, height: 12)
                        .overlay(Circle().strokeBorder(Color.ink, lineWidth: 2))
                        .offset(x: 1, y: 1)
                }
            }
            .bouncy(0.9)

            VStack(alignment: .leading, spacing: 3) {
                Text(Mock.greeting)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(.white.opacity(0.55))
                Text(name)
                    .font(.system(size: 19, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
            }

            Spacer(minLength: 0)

            Button {
                Haptics.rigid()
                app.unreadCount = 0
                app.showToast("Đã đọc tất cả thông báo", icon: "bell.badge.fill")
            } label: {
                ZStack(alignment: .topTrailing) {
                    Image(systemName: "bell.fill")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.9))
                        .frame(width: 46, height: 46)
                        .background {
                            Circle().fill(.ultraThinMaterial)
                            Circle().strokeBorder(Palette.stroke, lineWidth: 1)
                        }

                    if app.unreadCount > 0 {
                        Text("\(app.unreadCount)")
                            .font(.system(size: 10, weight: .bold, design: .rounded))
                            .foregroundStyle(.black)
                            .padding(.horizontal, 5)
                            .padding(.vertical, 2)
                            .background(Capsule().fill(Color.neonMint))
                            .offset(x: 2, y: -2)
                            .transition(.scale)
                    }
                }
            }
            .bouncy(0.9)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: app.unreadCount)
        }
    }
}

// MARK: - Hero card

struct HeroCard: View {
    @EnvironmentObject private var app: AppState
    @State private var appeared = false

    private let balance: Double = 162_550_000

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Label("Tổng tài sản", systemImage: "sparkles")
                    .font(.system(size: 12.5, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.78))
                    .padding(.horizontal, 11)
                    .padding(.vertical, 6)
                    .background(Capsule().fill(Color.white.opacity(0.16)))

                Spacer()

                Button {
                    Haptics.selection()
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                        app.balanceHidden.toggle()
                    }
                } label: {
                    Image(systemName: app.balanceHidden ? "eye.slash.fill" : "eye.fill")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 34, height: 34)
                        .background(Circle().fill(Color.white.opacity(0.16)))
                }
                .bouncy(0.88)
            }

            VStack(alignment: .leading, spacing: 8) {
                Text(app.balanceHidden ? "•••••••• ₫" : balance.vnd)
                    .font(.system(size: 34, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white)
                    .contentTransition(.numericText())
                    .minimumScaleFactor(0.6)
                    .lineLimit(1)

                HStack(spacing: 8) {
                    Label("+ 12,4%", systemImage: "arrow.up.right")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(Color.ink)
                        .padding(.horizontal, 9)
                        .padding(.vertical, 5)
                        .background(Capsule().fill(Color.neonMint))

                    Text("so với tháng trước")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(.white.opacity(0.7))
                }
            }

            Divider().overlay(Color.white.opacity(0.22))

            HStack(spacing: 0) {
                HeroStat(icon: "arrow.down.left", title: "Thu vào", value: "38,6 Tr")
                Rectangle()
                    .fill(Color.white.opacity(0.18))
                    .frame(width: 1, height: 34)
                HeroStat(icon: "arrow.up.right", title: "Chi ra", value: "12,1 Tr")
                Rectangle()
                    .fill(Color.white.opacity(0.18))
                    .frame(width: 1, height: 34)
                HeroStat(icon: "chart.pie.fill", title: "Tiết kiệm", value: "68%")
            }
        }
        .padding(22)
        .background {
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .fill(Palette.hero)
                .overlay {
                    RoundedRectangle(cornerRadius: 30, style: .continuous)
                        .fill(
                            RadialGradient(colors: [.white.opacity(0.28), .clear],
                                           center: .topTrailing, startRadius: 6, endRadius: 260)
                        )
                }
        }
        .overlay {
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .strokeBorder(Color.white.opacity(0.22), lineWidth: 1)
        }
        .shadow(color: Color.neonIndigo.opacity(0.45), radius: 26, x: 0, y: 16)
        .scaleEffect(appeared ? 1 : 0.95)
        .opacity(appeared ? 1 : 0)
        .onAppear {
            withAnimation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.05)) {
                appeared = true
            }
        }
    }
}

struct HeroStat: View {
    let icon: String
    let title: String
    let value: String

    var body: some View {
        VStack(spacing: 5) {
            Label(title, systemImage: icon)
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(.white.opacity(0.75))
            Text(value)
                .font(.system(size: 15, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Quick actions

struct QuickActionsRow: View {
    @EnvironmentObject private var app: AppState

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 14) {
                ForEach(Mock.quickActions) { action in
                    Button {
                        Haptics.soft()
                        app.showToast("Tính năng đang phát triển", icon: action.icon)
                    } label: {
                        VStack(spacing: 9) {
                            ZStack {
                                Circle()
                                    .fill(.ultraThinMaterial)
                                Circle()
                                    .fill(action.tint.opacity(0.18))
                                Circle()
                                    .strokeBorder(action.tint.opacity(0.45), lineWidth: 1)
                                Image(systemName: action.icon)
                                    .font(.system(size: 20, weight: .semibold))
                                    .foregroundStyle(action.tint)
                            }
                            .frame(width: 58, height: 58)
                            .shadow(color: action.tint.opacity(0.35), radius: 12, y: 6)

                            Text(action.title)
                                .font(.system(size: 11.5, weight: .medium))
                                .foregroundStyle(.white.opacity(0.75))
                        }
                        .frame(width: 72)
                    }
                    .bouncy(0.9)
                }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 4)
        }
        .scrollClipDisabled_iOS16()
    }
}

extension View {
    /// Giữ tương thích iOS 16 (scrollClipDisabled chỉ có từ iOS 17)
    @ViewBuilder func scrollClipDisabled_iOS16() -> some View {
        if #available(iOS 17.0, *) { self.scrollClipDisabled() } else { self }
    }
}

// MARK: - Section header

struct SectionHeader: View {
    let title: String
    var actionTitle: String = "Xem tất cả"
    var onTap: () -> Void = {}

    var body: some View {
        HStack {
            Text(title)
                .font(.system(size: 17, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Spacer()
            Button(action: onTap) {
                HStack(spacing: 3) {
                    Text(actionTitle)
                    Image(systemName: "chevron.right")
                        .font(.system(size: 10, weight: .bold))
                }
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(Color.neonCyan)
            }
            .bouncy(0.92)
        }
    }
}

// MARK: - Transaction row

struct TransactionRow: View {
    let tx: Transaction
    var onTap: () -> Void = {}

    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 15, style: .continuous)
                        .fill(tx.tint.opacity(0.16))
                    RoundedRectangle(cornerRadius: 15, style: .continuous)
                        .strokeBorder(tx.tint.opacity(0.35), lineWidth: 1)
                    Image(systemName: tx.icon)
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(tx.tint)
                }
                .frame(width: 46, height: 46)

                VStack(alignment: .leading, spacing: 3) {
                    Text(tx.title)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(.white)
                    Text(tx.subtitle)
                        .font(.system(size: 12, weight: .regular))
                        .foregroundStyle(.white.opacity(0.5))
                        .lineLimit(1)
                }

                Spacer(minLength: 6)

                VStack(alignment: .trailing, spacing: 3) {
                    Text(tx.signedText)
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .foregroundStyle(tx.kind == .income ? Color.neonMint : .white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                    Text(tx.time)
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.white.opacity(0.4))
                }
            }
            .glassCard(radius: 22, padding: 14)
        }
        .bouncy(0.97)
    }
}

// MARK: - Toast

struct ToastView: View {
    let message: ToastMessage

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: message.icon)
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(Color.neonCyan)
            Text(message.text)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(.white)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 13)
        .background {
            Capsule().fill(.ultraThinMaterial)
            Capsule().fill(Color.white.opacity(0.06))
        }
        .overlay(Capsule().strokeBorder(Palette.stroke, lineWidth: 1))
        .shadow(color: .black.opacity(0.5), radius: 18, y: 10)
    }
}

// MARK: - Bar chart (mock)

struct MiniBarChart: View {
    let bars: [InsightBar]
    @State private var grow = false

    var body: some View {
        HStack(alignment: .bottom, spacing: 12) {
            ForEach(Array(bars.enumerated()), id: \.element.id) { index, bar in
                VStack(spacing: 8) {
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .fill(Palette.hero)
                        .frame(height: grow ? max(14, 120 * bar.value) : 6)
                        .opacity(0.55 + bar.value * 0.45)
                        .animation(.spring(response: 0.6, dampingFraction: 0.75)
                            .delay(Double(index) * 0.05), value: grow)
                    Text(bar.label)
                        .font(.system(size: 10.5, weight: .medium))
                        .foregroundStyle(.white.opacity(0.5))
                }
                .frame(maxWidth: .infinity)
            }
        }
        .frame(height: 150, alignment: .bottom)
        .onAppear { grow = true }
    }
}
