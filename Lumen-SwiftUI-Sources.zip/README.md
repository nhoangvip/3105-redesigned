# Lumen — Modern Dark SwiftUI Dashboard

Target: iOS 16.0+ · Swift 5.9/6.x · SwiftUI · KHÔNG dùng thư viện bên thứ ba.

## Mở bằng Xcode
1. Xcode → File → New → Project… → iOS → App
2. Product Name: Lumen · Interface: SwiftUI · Language: Swift · Storage: None
3. Xoá file ContentView.swift và LumenApp.swift mà Xcode tạo sẵn.
4. Kéo thả toàn bộ các file .swift trong thư mục Sources/ vào project
   (nhớ tick "Copy items if needed" + target Lumen).
5. Project → General → Minimum Deployments: iOS 16.0.
6. Chọn simulator iPhone 15/16 Pro → Cmd + R.

## Xuất file .ipa
Xem hướng dẫn chi tiết trong BUILD.md
