//
//  HomeView.swift
//  Tab "Tổng quan": Header → Hero Card → Quick Actions → Danh sách giao dịch.
//

import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var app: AppState
    @State private var selectedFilter: String = "Tất cả"
    private let filters = ["Tất cả", "Chi tiêu", "Thu nhập", "Định kỳ"]

    private var filtered: [Transaction] {
        switch selectedFilter {
        case "Chi tiêu": return Mock.transactions.filter { $0.kind == .expense }
        case "Thu nhập": return Mock.transactions.filter { $0.kind == .income }
        case "Định kỳ":  return Mock.transactions.filter { $0.subtitle.contains("Định kỳ") || $0.subtitle.contains("Tự động") }
        default:         return Mock.transactions
        }
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 22) {
                HeaderBar().padding(.horizontal, 20)

                HeroCard().padding(.horizontal, 20)

                QuickActionsRow()

                // Mục tiêu tiết kiệm
                VStack(spacing: 14) {
                    SectionHeader(title: "Mục tiêu của bạn") {
                        app.showToast("Tính năng đang phát triển", icon: "target")
                    }

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 14) {
                            ForEach(Mock.goals, id: \.0) { goal in
                                GoalCard(title: goal.0, icon: goal.1, progress: goal.2, tint: goal.3)
                            }
                        }
                        .padding(.horizontal, 20)
                        .padding(.vertical, 2)
                    }
                    .scrollClipDisabled_iOS16()
                    .padding(.horizontal, -20)
                }
                .padding(.horizontal, 20)

                // Giao dịch
                VStack(spacing: 14) {
                    SectionHeader(title: "Giao dịch gần đây") {
                        app.showToast("Tính năng đang phát triển", icon: "list.bullet")
                    }

                    FilterChips(items: filters, selection: $selectedFilter)

                    LazyVStack(spacing: 12) {
                        ForEach(filtered) { tx in
                            TransactionRow(tx: tx) {
                                Haptics.light()
                                app.showToast("Chi tiết: \(tx.title)", icon: tx.icon)
                            }
                            .transition(.opacity.combined(with: .scale(scale: 0.97)))
                        }
                    }
                    .animation(.spring(response: 0.4, dampingFraction: 0.85), value: selectedFilter)
                }
                .padding(.horizontal, 20)

                Color.clear.frame(height: 110)   // chừa chỗ cho tab bar nổi
            }
            .padding(.top, 8)
        }
    }
}

// MARK: - Filter chips

struct FilterChips: View {
    let items: [String]
    @Binding var selection: String

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 9) {
                ForEach(items, id: \.self) { item in
                    let active = item == selection
                    Button {
                        Haptics.selection()
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                            selection = item
                        }
                    } label: {
                        Text(item)
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundStyle(active ? Color.ink : .white.opacity(0.7))
                            .padding(.horizontal, 15)
                            .padding(.vertical, 9)
                            .background {
                                if active {
                                    Capsule().fill(Color.white)
                                } else {
                                    Capsule().fill(.ultraThinMaterial)
                                    Capsule().strokeBorder(Color.white.opacity(0.14), lineWidth: 1)
                                }
                            }
                    }
                    .bouncy(0.93)
                }
            }
            .padding(.vertical, 2)
        }
        .scrollClipDisabled_iOS16()
    }
}

// MARK: - Goal card

struct GoalCard: View {
    let title: String
    let icon: String
    let progress: Double
    let tint: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Image(systemName: icon)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(tint)
                    .frame(width: 38, height: 38)
                    .background(Circle().fill(tint.opacity(0.16)))
                Spacer()
                Text("\(Int(progress * 100))%")
                    .font(.system(size: 13, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
            }

            Text(title)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(.white)
                .lineLimit(1)

            ProgressBar(progress: progress, tint: tint)
        }
        .frame(width: 180)
        .glassCard(radius: 24, padding: 16)
    }
}

struct ProgressBar: View {
    let progress: Double
    let tint: Color
    @State private var animated = false

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Capsule().fill(Color.white.opacity(0.1))
                Capsule()
                    .fill(LinearGradient(colors: [tint, tint.opacity(0.55)],
                                         startPoint: .leading, endPoint: .trailing))
                    .frame(width: geo.size.width * (animated ? progress : 0))
                    .shadow(color: tint.opacity(0.6), radius: 8, y: 2)
            }
        }
        .frame(height: 7)
        .onAppear {
            withAnimation(.spring(response: 0.9, dampingFraction: 0.85).delay(0.15)) {
                animated = true
            }
        }
    }
}
